# GuruLeague — Πακέτο v22 (ετοιμάστηκε με Claude, 05/07/2026)

## Α. Αρχεία για ΑΜΕΣΟ deploy (έτοιμα, μπαίνουν ως έχουν)

### 1. `index.html`  — αντικαθιστά το υπάρχον
Βασίστηκε στο τελευταίο index του repo `euroleague-guru-updates` (commit 02e7da6).
Τρεις αλλαγές, όλες ορατές στο `changes_v22.diff`:
- **`spin()` (μία συνάρτηση, ~γραμμή με το σχόλιο "v22")**: επιβράδυνση κουλοχέρη
  (ticks από 50ms → ~280ms με κυβικό easing) + pop animation στο κλείδωμα.
  Πιάνει αυτόματα όλα τα modes (tournament / world / local / advanced).
  Tuning: οι σταθερές `50+230*p*p*p` και `TICKS=20` — μεγαλύτερες τιμές = πιο αργό/δραματικό.
- **CSS**: προστέθηκε `@keyframes slotLock` + κλάση `.slot-lock` δίπλα στο `.locked`.
- **`ensureYearDB()`**: φίλτρο ασφαλείας `gp>=10` κατά το merge του db_year.json
  (με τα τωρινά δεδομένα δεν αλλάζει τίποτα — προστασία για μελλοντικά rebuilds).
- **SEO**: og:url / og:image / twitter:image από `euroleague-guru.vercel.app` → `guruleague.net`,
  προστέθηκε `<link rel="canonical">`.

### 2. `robots.txt` + 3. `sitemap.xml` — νέα αρχεία στο root του repo
Το Vercel τα σερβίρει αυτόματα. Μετά το deploy: δήλωση του guruleague.net στο
Google Search Console και υποβολή του sitemap (λύνει το ότι το site δεν βγαίνει σε αναζητήσεις).

### 4. `changes_v22.diff`
Το ακριβές git diff του index.html για γρήγορο review πριν το commit.

## Β. Αρχεία δεδομένων για το ΕΠΟΜΕΝΟ feature (εθνικότητες) — ΔΕΝ μπαίνουν στο site ακόμα

### 5. `nat_map.json`
Λεξικό `{ "Όνομα παίκτη": "ISO-3 κωδικός χώρας" }` και για τους 1.274 παίκτες του era DB.
Κανόνας: η ΕΘΝΙΚΗ ΟΜΑΔΑ που εκπροσώπησε ο παίκτης (Larkin→TUR, McCalebb→MKD, Calathes→GRE,
Mirotic/Ibaka→ESP), αλλιώς χώρα διαβατηρίου. Για το merge στο DB, στο build αρκεί:
`p.nat = NAT_MAP[p.name] || null` σε κάθε player object.

### 6. `Εθνικότητες_Παικτών.xlsx`
Η ίδια πληροφορία σε excel για έλεγχο. Η στήλη "Review" σημειώνει 138 περιπτώσεις
πολιτογραφημένων/διπλών υπηκοοτήτων — όσες γράφουν «τσέκαρε» θέλουν επιβεβαίωση.

### 7. `Χώρες_ανά_Era.xlsx`
Pool διαθέσιμων παικτών ανά χώρα × era. Συμπέρασμα: 10 χώρες περνούν το όριο ≥8
σε όλα τα eras (USA, SRB, GRE, ESP, LTU, TUR, ITA, RUS, HRV, ISR). FRA/GER
περνούν μόνο στα νεότερα eras → πρόταση: era-εξαρτώμενη ρόδα χωρών.

## Γ. Housekeeping

### 8. `Διπλογραφίες_DB.txt`
~20 περιπτώσεις όπου ο ίδιος παίκτης υπάρχει στο era DB με δύο γραφές
(π.χ. Motiejunas/Motiejūnas, Wade Baldwin/Wade Baldwin IV, Weiler-Babb/Weiler-babb,
και το κερασάκι: "Vlantimir Giankovits" = Vlado Jankovic). Θέλουν ενοποίηση στο DB
όποτε βολεύει — επηρεάζουν και τον έλεγχο «ίδιος παίκτης δύο φορές στην ομάδα».

## Προτεινόμενη σειρά
1. Review του diff → commit τα 1-3 (index, robots, sitemap) → deploy.
2. Search Console + sitemap.
3. Όποτε υπάρχει χρόνος: merge του nat στο DB (5'), ενοποίηση διπλογραφιών,
   και μετά χτίζουμε το Nationality mode + Daily Challenge.

Εκκρεμεί απόφαση (συζητήθηκε, δεν υλοποιήθηκε): eFG% ως 7η κατηγορία στο pairWinner
— ΠΡΟΣΟΧΗ: αλλάζει αναδρομικά αποτελέσματα σε leagues/ladders γιατί όλα επανυπολογίζονται.
